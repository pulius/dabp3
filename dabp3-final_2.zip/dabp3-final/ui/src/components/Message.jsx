import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const Message = ({message, postedTime, replies, addReply, id}) => {
    const [expanded, setExpanded] = useState(false)
    const [newReply, setNewReply] = useState("")

    const showButtonhandler = (e) => {
        e.preventDefault()
        setExpanded(!expanded)
    }

  return (
    <div>
      <h6>
        {message}
        <br></br>
        {postedTime}
      </h6>
      <br></br>
      {expanded &&
      <div>
      <textarea
        placeholder={"New reply"}
        id={"newReplyInput"}
        name={"newReply"}
        value={newReply}
        onChange={({target}) => setNewReply(target.value)}>
      </textarea>
      <br></br>
      <button
        type={"submit"}
        onClick={() =>  {
          addReply(newReply, id)
          setNewReply("")
          }}>
        submit
      </button>
        {replies.map(reply => 
        <li
        key={reply.replytext}
        >{reply.replytext}</li>
        )}
      </div>
      }
      <br></br>
      <button onClick={showButtonhandler}>{expanded? "hide": "show"} replies</button>
    </div>
  );
};

export default Message;
