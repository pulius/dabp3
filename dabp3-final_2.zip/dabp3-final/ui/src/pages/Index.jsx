import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ipsumData, tamiReplies } from "../ipsum-data";
import Message from "../components/Message";

const Index = () => {

  const [newMessage, setNewMessage] = useState("")
  const [messages, setMessages] = useState([])
  const [allReplies, setAllReplies] = useState([])

  let uuid = window.localStorage.getItem("uuid")
  if (!uuid) {
    uuid = crypto.randomUUID()
    window.localStorage.setItem("uuid", uuid)
  }

  const messageHook = () => {
    fetch(`http://localhost:7777/messages`)
    .then(response => response.json())
    .then(data => {setMessages(data.sort((a, b) => {
      let da = new Date(a.senttime),
          db = new Date(b.senttime);
      return db - da;
  }))
  })
  }

  const replyHook = () => {
    fetch(`http://localhost:7777/replies`)
    .then(response => response.json())
    .then(data => {setAllReplies(data)
    console.log(data)})
  }

  useEffect(messageHook,[])
  useEffect(replyHook,[])

  const addMessage = () => {
    if (newMessage !== "") {
    const id = (Math.floor(Math.random()* 1000000)).toString()
    const time = new Date().toISOString()
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: id, message: newMessage, time: time})
    };
      fetch('http://localhost:7777/messages', requestOptions)
          .then(response => response.json())
          .then(() => {
            const newMessages = [{ id: id, messagetext: newMessage, senttime: time.toString()}, ...messages]
            setMessages(newMessages.sort((a, b) => {
              let da = new Date(a.senttime),
                  db = new Date(b.senttime);
              return db - da;
          }))
            setNewMessage("")
          })
        }
  }

  const addReply = (replytext, replyto) => {
    if (replytext !== "") {
    const id = (Math.floor(Math.random()* 1000000)).toString()
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: id, replytext: replytext, replyto: replyto})
    };
      fetch('http://localhost:7777/replies', requestOptions)
          .then(response => response.json())
          .then(() => {
            const newReplies = [{ id: id, replytext: replytext, replyto: replyto}, ...allReplies]
            setAllReplies(newReplies)
          })
    }
  }

console.log(messages)
  return (
    <div>
      <h1>Hello to the world!!!</h1>
      <textarea
        placeholder={"New message"}
        id={"newMessageInput"}
        name={"newMessage"}
        value={newMessage}
        onChange={({target}) => setNewMessage(target.value)}>
      </textarea>
      <br></br>
      <button
        type={"submit"}
        onClick={addMessage}>
        submit
      </button>
      {messages.slice(0, 20).map(message => 
        <Message
          key={message.id}
          message={message.messagetext}
          postedTime={new Date(message.senttime).toISOString()}
          replies={allReplies.filter(reply => reply.replyto === message.id.toString())}
          addReply={addReply}
          id={message.id}>
        </Message>
        )}
    </div>
  );
};

export default Index;
