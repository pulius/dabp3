import {
  require_react
} from "./chunk-GCJ4REYC.js";
export default require_react();
//# sourceMappingURL=react.js.map
