# Project 3 report

# Introduction
This application consists of a React/Vite frontend, running on an Oak backend with a Postgres database. The Kubernetes deployment uses the Docker Desktop's Kubernetes functionalities and CloudnativePG for the database.

# Running the application and tests
The application can be run locally in Docker with the command `docker compose up --build` at the root folder.
NOTE: If the database refuses connection on the first startup, do a change (e.g, write a comment) to the api/app.js file. Then kill the docker instance and run `docker compose up --build` again. 

The tests can be run from the tests folder with the command `k6 run TEST_FILE_NAME.js`.

# Deploying to Kubernetes
1. Run the application in Docker as instructed above, if you haven't done so already. Remember to shut down the Docker instance so the ports aren't reserved.
2. Change the backend to use "hostname" instead of "host" for the database connection by commenting out row 44 and uncommenting row 43 in api/app.js. 
3. Build the images again by running e.g., `docker compose up --build`.
4. Enable Kubernetes on Docker Desktop (here's a good tutorial if needed: https://birthday.play-with-docker.com/kubernetes-docker-desktop/).
5. Make sure that you are using the Docker Desktop context. (This can be checked by running `kubectl config get-contexts`).
6. Install CloudNativePG by running `kubectl apply -f https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.18/releases/cnpg-1.18.0.yaml`.
7. Make sure that you are in the kubernetes folder. Then start the database cluster by running `kubectl apply -f my-database-config.yaml`.
8. When the db is up and running, start the rest of the app by running `kubectl apply -f my-api-service.yaml,my-api.yaml,my-app-nginx-ingress.yaml,my-ui-service.yaml,my-ui.yaml`.
9. Apply scaling to the backend by running `kubectl autoscale deployment/api --min=2 --max=4 --cpu-percent=80` (CloudnativePG takes care of scaling the database).

# Lighthouse performance:

| Performance | Accessibility | Best Practises | SEO |
|-------------|---------------|----------------|-----|
| 76          | 96            | 100            | 89  | 
----------------------------------------------------------------------------
| First Contentful Paint | Time to Interactive | Speed Index |
|------------------------|---------------------|-------------|
| 1.5s                   | 1.5s                | 1.6s        | 
----------------------------------------------------------------------------
| Total Blocking Time | Largest Contentful Paint | Cumulative Layout Shift |
|---------------------|--------------------------|-------------------------|
| 0ms                 | 2.8s                     | 0.111                   | 

# K6 Performance tests:

Without adding a message/reply:
| Avg. requests per second| Median  | 95th percentile | 99th percentile |
|-------------------------|---------|-----------------|-----------------|
|           1470          | 18.51ms |     29.5ms      |    56.72ms      | 

When adding a message:
| Avg. requests per second| Median  | 95th percentile | 99th percentile |
|-------------------------|---------|-----------------|-----------------|
|           59            |  13ms   |      1.08s      |      1.42s      | 

When adding a reply:
| Avg. requests per second| Median  | 95th percentile | 99th percentile |
|-------------------------|---------|-----------------|-----------------|
|           85            | 10.99ms |     128.54ms    |     495.9ms     | 

# Application performance reflection:

The frontend feels quite responsive, though it would be an accomplishment to create a badly responsive frontend with React. The backend also answers swiftly, which makes using the application pretty pleasant. The performance scores aren't perfect, but with my skills they are acceptable. However, it is a bit surprising to see such a difference between the response times when adding a message comapred to adding a reply, even though their implementations are almost identical. The Kubernetes setup is pretty basic and since I'm not working with a high-end pc, I had to make the allocations quite small to be able to run the configuration on my pc. Overall I would say that the performance is good enough for a project like this.

# Suggestions

The Lighthouse scores would get better if the application would serve more static content, since the current configuration renders a bit too extensively on the client-side. The database migration for Kubernetes is not the smartest one: Since I was not able to make Flyway work correctly, the backend creates the needed tables in a error handler that fires when the frontend tries to fetch the messages on initial load. As stated above, the Kubernetes configuration would highly benefit from more resources if we were going to scale it to a larger user base. Then, of course, a more sophisticated message-exchange system would yield performance on a bigger scale.