CREATE TABLE messages (
    id TEXT PRIMARY KEY,
    messagetext TEXT,
    senttime TEXT
);

CREATE TABLE replies (
    id TEXT PRIMARY KEY,
    replytext TEXT,
    replyto TEXT
);

INSERT INTO messages
("id", "messagetext", "senttime")
VALUES
('1', 'testiteksti', '2022-12-07T21:16:36.740Z');

INSERT INTO replies
("id", "replytext", "replyto")
VALUES
('12345', 'siisti postaus', '1');

INSERT INTO messages
("id", "messagetext", "senttime")
VALUES
('2', 'tami on kuningas', '2022-12-06T11:15:33.675Z');

INSERT INTO replies
("id", "replytext", "replyto")
VALUES
('5555', 'Samaa mieltä!', '1');
