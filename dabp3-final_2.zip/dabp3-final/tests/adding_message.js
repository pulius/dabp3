import http from "k6/http";
export const options = {
 duration: "10s",
 vus: 30,
 summaryTrendStats: ["med", "p(95)", "p(99)"],
};

export default function () {
let res = http.post(
    "http://localhost:7777/messages", 
    JSON.stringify({ id: `${(Math.floor(Math.random()*100000).toString())}`, message: 'Testing message', time: '2015-08-18T21:50:27.867Z'}), {
    headers: { 'Content-Type': 'application/json' }
    })
    console.log(res)
}