import { Application, Router } from "https://deno.land/x/oak@v11.1.0/mod.ts";
import { oakCors } from "https://deno.land/x/cors@v1.2.2/mod.ts";
import { Pool } from "https://deno.land/x/postgres@v0.17.0/mod.ts";

const app = new Application()
const router = new Router()

const PGPASS = Deno.env.get("PGPASS");
const PGPASS_PARTS = PGPASS.split(":");
const host = PGPASS_PARTS[0].trim();
const port = PGPASS_PARTS[1].trim();
const database = PGPASS_PARTS[2].trim();
const user = PGPASS_PARTS[3].trim();
const password = PGPASS_PARTS[4].trim();
console.log("PGPASS: " + PGPASS)

// DB migration for Kubernetes so we dont have to deal with flyway
const initDB = async (client) => {
  const checkMessagesQueryString = `SELECT * FROM pg_catalog.pg_tables WHERE tablename = 'messages';`
  const checkMessages = await client.queryObject(checkMessagesQueryString)
  if (!checkMessages.rows) {
    const createMessagesQueryString = `CREATE TABLE messages ( id TEXT PRIMARY KEY, messagetext TEXT, senttime TEXT );`
    await client.queryObject(createMessagesQueryString)
    const createExampleMessageQueryString = `INSERT INTO messages ("id", "messagetext", "senttime" ) VALUES ('123465', 'First message', '2022-12-11T11:33:20.464Z');`
    await client.queryObject(createExampleMessageQueryString)    
  }

  const checkRepliesQueryString = `SELECT * FROM pg_catalog.pg_tables WHERE tablename = 'replies';`
  const checkReplies = await client.queryObject(checkRepliesQueryString)
  if (!checkReplies.rows) {
    const createRepliesQueryString = `CREATE TABLE replies ( id TEXT PRIMARY KEY, replytext TEXT, replyto TEXT );`
    await client.queryObject(createRepliesQueryString)
    const createExampleReplyQueryString = `INSERT INTO replies ("id", "replytext", "replyto" ) VALUES ('87653', 'That is a cool message!', '123465');`
    await client.queryObject(createExampleReplyQueryString)   
  }
}

const CONCURRENT_CONNECTIONS = 10;
const connectionPool = new Pool({
  user:user,
  database:database,
  port:port,
  //hostname:host, // UNCOMMENT THIS WHEN USING KUBERNETES
  host:host, // UNCOMMENT THIS WHEN USING DOCKER
  password:password
}, CONCURRENT_CONNECTIONS);

router.post("/messages", async (ctx) => {

  const data = await ctx.request.body().value
  console.log("data: " + data)
  const json = JSON.parse(JSON.stringify(data))
  console.log("json: " + json)

  const id = await json.id
  const message = await  json.message
  const time = await json.time

  const client = await connectionPool.connect();
  
  const queryString = `INSERT INTO messages ("id", "messagetext", "senttime" ) VALUES ('${id}', '${message}', '${time}');`
  
  console.log("query string: " + queryString)

  try {
    await client.queryObject(queryString);
  } catch {
    initDB(client)
  }
  await client.release();
  ctx.response.body = (JSON.stringify({json}))

})

router.post("/replies", async (ctx) => {

  const data = await ctx.request.body().value
  console.log("data: " + data)
  const json = JSON.parse(JSON.stringify(data))
  console.log("json: " + json)

  const id = await json.id
  const replytext = await  json.replytext
  const replyto = await json.replyto

  const client = await connectionPool.connect();
  
  const queryString = `INSERT INTO replies ("id", "replytext", "replyto" ) VALUES ('${id}', '${replytext}', '${replyto}');`
  
  console.log("reply query string: " + queryString)
  try {
  await client.queryObject(queryString);
  } catch {
    initDB(client)
  }
  await client.release();
  ctx.response.body = (JSON.stringify({json}))

})

router.get("/messages", async (ctx) => {
  const client = await connectionPool.connect();
  try {
    let existingResults = await client.queryObject(`SELECT * FROM messages`)
    if (existingResults.rows) {
      ctx.response.body = JSON.stringify(existingResults.rows);
    }
} catch {
    initDB(client)
} 
})

router.get("/replies", async (ctx) => {
  const client = await connectionPool.connect();
  try {
  let existingResults = await client.queryObject(`SELECT * FROM replies`)
  if (existingResults.rows) {
    ctx.response.body = JSON.stringify(existingResults.rows);
  }
} catch {
  initDB(client)
}
})

app.use(oakCors());
app.use(router.routes())
app.use(router.allowedMethods())

app.listen({port: 7777})
